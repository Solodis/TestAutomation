package com.epam.vyacheslav_utenkov.java.lesson2.task2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airplane;

public class FileHandler {
	
	private static List<Airplane> objectList = new ArrayList<Airplane>();
	
	public static List<Airplane> getObjectArray(File file){
		
		try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file))){
			
			objectList = (List<Airplane>) objectInputStream.readObject();
			
			objectInputStream.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return objectList;
	}
	
	public static void writeObjectInFile(List<Airplane> airplanes, File file){
		try(ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(file))){
			objectOutputStream.writeObject(airplanes);
			objectOutputStream.flush();
			objectOutputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
}
