package com.epam.vyacheslav_utenkov.java.lesson2.task2;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.airline.ControlRoom;

/**
 * 
 * @author Vyacheslav_Utenkov
 * @category Home Task L2
 */

public class ApplicationRunner {

	public static void main(String[] args) {

		ControlRoom controlRoom = new ControlRoom();
		
		controlRoom.run();

	}

}
