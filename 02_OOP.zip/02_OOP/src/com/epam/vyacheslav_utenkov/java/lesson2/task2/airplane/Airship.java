package com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane;

public class Airship extends Airplane {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4143041092708672544L;

	public Airship(String name, int range, double weight, int placeCount) {
		super(name, range, weight, placeCount);
	}

}
