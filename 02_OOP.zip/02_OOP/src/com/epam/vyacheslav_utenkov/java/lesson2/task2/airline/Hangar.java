package com.epam.vyacheslav_utenkov.java.lesson2.task2.airline;

import java.io.File;
import java.util.ArrayList; 
import java.util.List;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.FileHandler;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airplane;

public class Hangar {

	private List<Airplane> airplanes = new ArrayList<Airplane>();
	private File file = new File("airplanes.txt");
	
	public void addAirplane(Airplane airplane) {
		airplanes = FileHandler.getObjectArray(this.file);
		airplanes.add(airplane);
		FileHandler.writeObjectInFile(airplanes, this.file);
	}
	
	public Airplane getAirplane(int index) {
		airplanes = FileHandler.getObjectArray(this.file);
		return airplanes.get(index);
	}

	public void removeAirplane(int index) {
		airplanes = FileHandler.getObjectArray(this.file);
		airplanes.remove(index);
		FileHandler.writeObjectInFile(airplanes, this.file);
	}

	public List<Airplane> getAirplansList() {
		return FileHandler.getObjectArray(this.file);
		
	}
	
	public void setAirplanes(List<Airplane> airplanes) {
		FileHandler.writeObjectInFile(airplanes, file);
	}

}
