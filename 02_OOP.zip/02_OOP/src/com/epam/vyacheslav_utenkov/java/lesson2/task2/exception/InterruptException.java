package com.epam.vyacheslav_utenkov.java.lesson2.task2.exception;

public class InterruptException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2457956783616426084L;

}
