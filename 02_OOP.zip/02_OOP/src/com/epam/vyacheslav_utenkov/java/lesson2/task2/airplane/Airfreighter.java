package com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane;

public class Airfreighter extends Airplane {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2600707723122318975L;

	public Airfreighter(String name, int range, double weight, int placeCount) {
		super(name, range, weight, range);

	}

}
