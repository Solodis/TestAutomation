package com.epam.vyacheslav_utenkov.java.lesson2.task2.airline;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.ConsoleHelper; 
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.*;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.exception.InterruptException;


public class ControlRoom {
	private static final String NAME = "Please insert airline name";
	private static final String PARTING = "Good bye!";
	private static final int AIRPLANE_COUNT = 3;
	Airline airline;

	public ControlRoom(Airline airline) {
		this.airline = airline;
	}

	public ControlRoom() {

	}

	public void run(){
		ConsoleHelper.writeMessage(NAME);
		String name;
		try {
			name = ConsoleHelper.readString();
			airline = getDefaultAirline(name);
			ConsoleHelper.workWithUser(airline);
		} catch (InterruptException e) {
			ConsoleHelper.writeMessage(PARTING);
		}
		
	}

	public Airline getDefaultAirline(String name) {
		Airline airline = new Airline(name);

		for (int i = 0; i < AIRPLANE_COUNT; i++) {
			airline.setAirplane(new Airliner("ТУ-154", (int) (Math.random() * 100000), Math.random() * 10000 / 10,
					(int) (Math.random() * 10000) / 100));
			airline.setAirplane(new Airfreighter("ИЛ-96", (int) (Math.random() * 100000), Math.random() * 10000 / 10,
					(int) (Math.random() * 10000) / 100));
			airline.setAirplane(new Helicopter("ИЛ-96", (int) (Math.random() * 100000), Math.random() * 10000 / 10,
					(int) (Math.random() * 10000) / 100));
			airline.setAirplane(new Airship("ИЛ-96", (int) (Math.random() * 100000), Math.random() * 10000 / 10,
					(int) (Math.random() * 10000) / 100));
		}
		
		return airline;
	}

}
