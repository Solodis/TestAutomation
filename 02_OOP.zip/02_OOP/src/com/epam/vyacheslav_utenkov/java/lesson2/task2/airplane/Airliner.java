package com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane;

public class Airliner extends Airplane{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8882937838765914967L;

	public Airliner(String name, int range, double weight, int placeCount) {
		super(name, range, weight, placeCount);
		
	}

}
