package com.epam.vyacheslav_utenkov.java.lesson2.task2;

import java.io.BufferedReader; 
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.airline.Airline;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airline.AirplaneType;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airplane;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.exception.InterruptException;

public class ConsoleHelper {

	private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	private static final String MAIN_MENU_TEXT = "Please insert command\n1 - Show all Airplane\n2 - Delete airplane\n3 - Sort airplane\n4 - Insert airplane\n5 - Search\n6 - Show total sum of values\nEXIT - Exit";
	private static final String AIRPLANE_MENU_TEXT = "Please insert type of airplane\n1 - Airliner\n2 - Airfreighter\n3 - Helicopter\n4 - Airship\nRETURN - Return";
	private static final String SORT_MENU_TEXT = "Please insert criterion\nName\nRange\nWeight\nPlace count\nRETURN - Return\nEXIT - Exit";
	private static final String DELETE_MENU_TEXT = "Please insert index for remove";
	private static final String VALUES_MENU = "Please insert min and max value";
	private static final String WRONG_COMMAND = "Wrong command";
	private static final String INSERT_MENU_TEXT = "Please insert \"name\", \"range\", \"weight\", \"place count\"";
	private static final String EMPTY = "List is empty";
	public static final String NAME = "Name";
	public static final String RANGE = "Range";
	public static final String PLACE_COUNT = "PlaceCount";
	public static final String WEIGHT = "Weight";
	public static final String SHOW = "1";
	public static final String DELETE = "2";
	public static final String SORT = "3";
	public static final String INSERT = "4";
	public static final String SEARCH = "5";
	public static final String SUM_OF_VALUE = "6";
	public static final String EXIT = "exit";
	public static final String RETURN = "return";

	public static void writeMessage(String message) {
		System.out.println(message);
	}

	public static String readString() throws InterruptException {

		String line = "";
		try {
			line = reader.readLine().replaceAll("\\s", "");
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (line.equalsIgnoreCase(EXIT)) {
			throw new InterruptException();
		}

		return line;
	}

	public static int readInt() throws InterruptException {
		return Integer.parseInt(readString());
	}

	public static void workWithUser(Airline airline) throws InterruptException {

		String command = SHOW;
		while (!command.equalsIgnoreCase(EXIT)) {
			writeMessage(MAIN_MENU_TEXT);
			command = readString();
			if (command.equals(SORT)) {
				getSortMenu(airline, command);
			} else if (command.equals(SHOW)) {
				airline.showAirplanes();
			} else if (command.equals(DELETE)) {
				getDeleteMenu(airline, command);
			} else if (command.equals(INSERT)) {
				getInserteMenu(airline, command);
			} else if (command.equals(SEARCH)) {
				getSearchMenu(airline, command);
			} else if (command.equals(SUM_OF_VALUE)) {
				writeMessage(SORT_MENU_TEXT);
				String criterion = readString();
				airline.showSumOfValues(criterion);
			} else {
				ConsoleHelper.writeMessage(WRONG_COMMAND);
			}
		}
	}

	private static void getSortMenu(Airline airline, String command) throws InterruptException {
		while (!command.equals(RETURN)) {
			writeMessage(AIRPLANE_MENU_TEXT);
			String airplaneType = readString();
			if (airplaneType.equalsIgnoreCase(RETURN)) {
				break;
			}
			try {
				List<Airplane> airplanes = airline.getAirplanes(AirplaneType.geAirplaneType(airplaneType));
				if (airplanes.isEmpty()) {
					writeMessage(EMPTY);
					break;
				}
				writeMessage(SORT_MENU_TEXT);
				airline.workWithSort(airplanes);
			} catch (IllegalArgumentException e) {
				if (!airplaneType.equalsIgnoreCase(RETURN)) {
					writeMessage(WRONG_COMMAND);
				} else {
					command = RETURN;
				}
			}
		}
	}

	private static void getDeleteMenu(Airline airline, String command) throws InterruptException {
		while (!command.equals(RETURN)) {
			if (airline.getAirplanes().isEmpty()) {
				writeMessage(EMPTY);
				break;
			}
			String index;
			writeMessage(DELETE_MENU_TEXT);
			try {
				airline.showAirplanes();
				index = readString();
				if(!index.equalsIgnoreCase(RETURN)){
					airline.workWithDelete(Integer.parseInt(index));
				}else{
					command = RETURN;
				}
				
			} catch (NumberFormatException e) {
				writeMessage(WRONG_COMMAND);
			} 
		}
	}

	private static void getInserteMenu(Airline airline, String command) throws InterruptException {
		while (!command.equals(RETURN)) {
			ConsoleHelper.writeMessage(AIRPLANE_MENU_TEXT);
			String num = readString();
			try {
				AirplaneType airplaneType = AirplaneType.geAirplaneType(num);
				writeMessage(INSERT_MENU_TEXT);
				airline.workWithInsert(airplaneType);
			} catch (NumberFormatException e) {
				writeMessage(WRONG_COMMAND);
			} catch (IllegalArgumentException l) {
				if (!num.equalsIgnoreCase(RETURN)) {
					writeMessage(WRONG_COMMAND);
				} else {
					command = RETURN;
				}
			}
		}
	}

	private static void getSearchMenu(Airline airline, String command) throws InterruptException {
		while (!command.equalsIgnoreCase(RETURN)) {
			writeMessage(SORT_MENU_TEXT);
			String criterion = readString();
			if (!criterion.equalsIgnoreCase(RETURN)) {
				try {
					writeMessage(VALUES_MENU);
					int minValue = readInt();
					int maxValue = readInt();
					airline.searchBetweenValues(criterion, minValue, maxValue);
				} catch (NumberFormatException e) {
					writeMessage(WRONG_COMMAND);
				}
			} else {
				command = RETURN;
			}
		}
	}

}
