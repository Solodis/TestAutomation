package com.epam.vyacheslav_utenkov.java.lesson2.task2.airline;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.ConsoleHelper;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.FileHandler;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airfreighter;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airliner;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airplane;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.exception.InterruptException;

public class Airline {
	private String name;
	private Hangar hangar = new Hangar();

	public Airline(String name){
		this.setName(name);

	}

	public Hangar getHangar() {
		return hangar;
	}

	public void setAirplane(Airplane airplane) {
		hangar.addAirplane(airplane);
	}

	private void removeAirplane(int index) {
		hangar.removeAirplane(index);
	}

	public void showAirplanes() {
		List<Airplane> airplanes = hangar.getAirplansList();
		for (int i = 0; i < airplanes.size(); i++) {
			ConsoleHelper.writeMessage("Airplane: " + getAirplanes().get(i) + " index: " + i);
		}
	}

	public Airplane getAirplane(int index) {
		return hangar.getAirplane(index);

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Airplane> getAirplanes(AirplaneType airplaneType) {

		if (AirplaneType.AIRLINERS == airplaneType) {
			return AirplaneType.AIRLINERS.getAirplaneList(getAirplanes());
		} else if (AirplaneType.AIRFREIGHTER == airplaneType) {
			return AirplaneType.AIRFREIGHTER.getAirplaneList(getAirplanes());
		} else if (AirplaneType.HELICOPTER == airplaneType) {
			return AirplaneType.HELICOPTER.getAirplaneList(getAirplanes());
		} else if (AirplaneType.AIRSHIP == airplaneType) {
			return AirplaneType.AIRSHIP.getAirplaneList(getAirplanes());
		} else {
			return AirplaneType.ALL.getAirplaneList(getAirplanes());
		}

	}

	public List<Airplane> getAirplanes() {
		return hangar.getAirplansList();
	}

	public void workWithInsert(AirplaneType airplaneType) throws InterruptException {
		String name = ConsoleHelper.readString();
		int range = Integer.parseInt(ConsoleHelper.readString());
		double weight = Double.parseDouble(ConsoleHelper.readString());
		int placeCount = Integer.parseInt(ConsoleHelper.readString());
		if (AirplaneType.AIRLINERS == airplaneType) {
			setAirplane(new Airliner(name, range, weight, placeCount));
		} else if (AirplaneType.AIRFREIGHTER == airplaneType) {
			setAirplane(new Airfreighter(name, range, weight, placeCount));
		}
	}

	public void workWithSort(List<Airplane> airplanes) throws InterruptException {
		String sortCriterion = ConsoleHelper.readString();
		for (Airplane airplane : airplanes) {
			airplane.setCriterion(sortCriterion);
		}
		Collections.sort(airplanes);
		for (Airplane airplane : airplanes) {
			ConsoleHelper.writeMessage(airplane.toString());
		}
	}

	public void workWithDelete(int index) throws InterruptException {

			removeAirplane(index);
	}

	public void searchBetweenValues(String criterion, double minValue, double maxValue) {
		if (criterion.equalsIgnoreCase(ConsoleHelper.NAME)) {
			// "This part of the program is not working yet";
		} else {
			for (Airplane airplane : getAirplanes()) {
				airplane.setCriterion(criterion);
				if (airplane.getCriterion() >= minValue && airplane.getCriterion() <= maxValue) {
					ConsoleHelper.writeMessage(airplane.toString());
				}
			}
		}
	}

	public void showSumOfValues(String criterion) {
		int totalValue = 0;
		for (Airplane airplane : getAirplanes()) {
			airplane.setCriterion(criterion);
			totalValue += airplane.getCriterion();
		}
		ConsoleHelper.writeMessage("Total " + criterion + " is: " + String.valueOf(totalValue));
	}
	
	public void writeInFile(List<Airplane> list, File file){
		FileHandler.writeObjectInFile(list, file);
	}
	
	public List<Airplane> readFromFile(File file){
		List<Airplane> airplanes = new ArrayList<Airplane>();
		for (Airplane object : FileHandler.getObjectArray(file)) {
			airplanes.add(((Airplane) object));
		}
		return airplanes;
		
	}

}
