package com.epam.vyacheslav_utenkov.java.lesson2.task2.exception;

public class CriterionNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
