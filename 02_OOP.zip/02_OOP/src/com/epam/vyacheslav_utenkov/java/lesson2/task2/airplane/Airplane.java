package com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane;

import java.io.Serializable; 

import com.epam.vyacheslav_utenkov.java.lesson2.task2.ConsoleHelper;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.exception.CriterionNotFoundException;

public abstract class Airplane implements Comparable<Object>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2490342899574030354L;
	protected int range;
	protected String name;
	protected double weight;
	protected int placeCount;
	private String criterion = "1";

	public Airplane(String name, int range, double weight, int placeCount) {
		this.weight = weight;
		this.name = name;
		this.range = range;
		this.placeCount = placeCount;

	}

	public String getName() {
		return name;
	}

	public int getRange() {
		return range;
	}
	
	@Override
	public int compareTo(Object o) {
		Airplane anotherAirplane = null;
		if (o != null) {
			if (o instanceof Airplane) {
				anotherAirplane = (Airplane) o;
				if(this.criterion.equalsIgnoreCase(ConsoleHelper.NAME)){
					return this.getName().compareTo(anotherAirplane.getName());
				}
				return (int) (this.getCriterion() - anotherAirplane.getCriterion());
			}else {
				throw new NullPointerException();
			}
			
		} else {
			throw new NullPointerException();
		}
		

	}

	public double getCriterion(){
		if(criterion.equalsIgnoreCase(ConsoleHelper.RANGE)){
			return this.getRange();
		}else if(criterion.equalsIgnoreCase(ConsoleHelper.WEIGHT)){
			return this.getWeight();
		} else if(criterion.equalsIgnoreCase(ConsoleHelper.PLACE_COUNT)){
			return this.getPlaceCount();
		} else {
			throw new CriterionNotFoundException();
		}
		
	}

	public void setCriterion(String criterion) {
		this.criterion = criterion;
	}
	
	public int getPlaceCount() {
		return placeCount;
	}
	
	@Override
	public String toString() {

		return "Airplane: " + name + " range: " + range + " weight: " + weight;
	}
	
	public double getWeight() {
		return weight;
	}

}
