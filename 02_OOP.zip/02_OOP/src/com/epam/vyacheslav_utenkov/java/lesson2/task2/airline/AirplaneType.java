package com.epam.vyacheslav_utenkov.java.lesson2.task2.airline;

import java.util.ArrayList;
import java.util.List;

import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airfreighter;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airliner;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Airplane;
import com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane.Helicopter;

public enum AirplaneType {
	ALL {
		@Override
		public List<Airplane> getAirplaneList(List<Airplane> airplanes) {
			return airplanes;
		}
	},
	AIRLINERS {
		@Override
		public List<Airplane> getAirplaneList(List<Airplane> airplanes) {
			List<Airplane> airliners = new ArrayList<>();
			for (Airplane airplane : airplanes) {
				if (airplane instanceof Airliner) {
					airliners.add(airplane);
				}
			}
			return airliners;
		}

	},
	AIRFREIGHTER {
		@Override
		public List<Airplane> getAirplaneList(List<Airplane> airplanes) {
			List<Airplane> airfreighters = new ArrayList<>();
			for (Airplane airplane : airplanes) {
				if (airplane instanceof Airfreighter) {
					airfreighters.add(airplane);
				}
			}
			return airfreighters;
		}

	},
	HELICOPTER {

		@Override
		public List<Airplane> getAirplaneList(List<Airplane> airplanes) {
			List<Airplane> helicopters = new ArrayList<>();
			for (Airplane airplane : airplanes) {
				if (airplane instanceof Helicopter) {
					helicopters.add(airplane);
				}
			}
			return helicopters;
		}

	},
	AIRSHIP {

		@Override
		public List<Airplane> getAirplaneList(List<Airplane> airplanes) {
			List<Airplane> airships = new ArrayList<>();
			for (Airplane airplane : airplanes) {
				if (airplane instanceof Airliner) {
					airships.add(airplane);
				}
			}
			return airships;
		}

	};

	public static AirplaneType geAirplaneType(String num) {
		if (num.equals("1")) {
			return AIRLINERS;
		} else if (num.equals("2")) {
			return AIRFREIGHTER;
		} else if (num.equals("3")) {
			return HELICOPTER;
		} else if (num.equals("4")) {
			return AIRSHIP;
		} else {
			throw new IllegalArgumentException();
		}
	}

	public abstract List<Airplane> getAirplaneList(List<Airplane> airplanes);
}
