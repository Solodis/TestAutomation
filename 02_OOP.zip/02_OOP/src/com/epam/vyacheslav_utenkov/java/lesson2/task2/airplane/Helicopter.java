package com.epam.vyacheslav_utenkov.java.lesson2.task2.airplane;

public class Helicopter extends Airplane {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6419260962396557625L;

	public Helicopter(String name, int range, double weight, int placeCount) {
		super(name, range, weight, placeCount);
	}

}
