package com.epam.vyacheslav_utenkov.java.lesson7;

import org.openqa.selenium.By;  
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MailTest {

	private WebDriver driver;

	@BeforeClass
	public void startBrowser() {
		driver = new FirefoxDriver();
		driver.get(WebElementData.URL);
	}

	@Test
	public void actionInBrowser() {

		WebElement loginInsert = driver.findElement(By.name(WebElementData.LOGIN_ELMENT_NAME));
		loginInsert.sendKeys(PersonalData.LOGIN);

		WebElement loginPassword = driver.findElement(By.name(WebElementData.PASSWORD_ELEMEN_NAME));
		loginPassword.sendKeys(PersonalData.PASSWORD);

		WebElement sighInButton = driver.findElement(By.xpath(WebElementData.SIGH_IN_XPATH));
		sighInButton.click();
		
		WebElement writeMessageButton = driver.findElement(By.xpath(WebElementData.WRITE_MESSAGE_BUTTON_XPATH));
		writeMessageButton.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		WebElement addresseeArea = driver.findElement(By.xpath(WebElementData.INSERT_ADDRESSEE_AREA_XPATH));
		addresseeArea.sendKeys(PersonalData.ADDRESSEE);
		
		WebElement messageArea = driver.findElement(By.xpath(WebElementData.MESSAGE_AREA_XPATH));
		messageArea.click();
		messageArea.sendKeys(PersonalData.MESSAGE);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
	}

	@AfterClass
	public void closeBrowser() {
		driver.quit();

	}

}
