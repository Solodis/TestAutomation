package com.epam.vyacheslav_utenkov.java.lesson7;

public class PersonalData {
	public static final String PASSWORD = "123456789spll";
	public static final String LOGIN = "vyacheslav.utenkov1990@yandex.ru";
	public static final String ADDRESSEE = "horns.and.hooves@yandex.ru";
	public static final String MESSAGE = "Hello world!";
	

}
