package com.epam.vyacheslav_utenkov.java.lesson7;

public class WebElementData {
	public static final String URL = "https://www.yandex.ru/";
	public static final String SIGH_IN_XPATH = "/html/body/div[1]/div[1]/div/div/div/div[3]/div/div/div[2]/div/div[2]/div/div/div/form/div/div[2]/div[2]/button";
	public static final String LOGIN_ELMENT_NAME = "login";
	public static final String PASSWORD_ELEMEN_NAME = "passwd";
	public static final String WRITE_MESSAGE_BUTTON_XPATH = "//*[@id=\"js-page\"]/div/div[5]/div/div[3]/div/div[2]/div/div/div/div[2]/a[2]";
	public static final String INSERT_ADDRESSEE_AREA_XPATH = "//*[@id=\"js-page\"]/div/div[5]/div/div[3]/div/div[3]/div/div/div/div/div/div/form/table/tbody/tr[3]/td[2]";
	public static final String MESSAGE_AREA_XPATH = "//*[@id=\"compose-send_ifr\"]";
	
}
