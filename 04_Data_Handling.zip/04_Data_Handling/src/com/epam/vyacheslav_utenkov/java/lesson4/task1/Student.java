package com.epam.vyacheslav_utenkov.java.lesson4.task1;

public class Student {
	
	private Programm programm;
	private String name;

	public Student(String name, Programm programm) {
		this.name = name;
		this.programm = programm;
	}
	
	public Student(String name, String programmName) {
		this.name = name;
		this.programm = new Programm(programmName);
		
	}

	public void getLightData() {
		ConsoleHelper.writeMessage(getName() + " (" + getProgramm().getProgrammName() + ") ");
	}
	
	public void getFullData() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Programm getProgramm() {
		return programm;
	}
	
	public void setProgramm(Programm programm) {
		this.programm = programm;
	}

}
