package com.epam.vyacheslav_utenkov.java.lesson4.task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ConsoleHelper {

	private static EducationalCenter educationalCenter = new EducationalCenter();
	private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	private static final String MENU = "0 - Light edition; 1 - Full edition; 3 - EXIT";
	private static final String EXIT = "3";
	private static final String ERROR = "Wrong command! please try again";

	public static void writeMessage(String message) {
		System.out.println(message);
	}

	public static String readString() {

		String line = "";
		try {
			line = reader.readLine().replaceAll("\\s", "");
		} catch (IOException e) {
			e.printStackTrace();
		}

		return line;
	}

	public static void workWithUser() {
		writeMessage(MENU);
		String edition = readString();
		while (!edition.equals(EXIT)) {
			try {
				educationalCenter.showStudentData(edition);
			} catch (IllegalAccessException e) {
				writeMessage(ERROR);
			}
		}

	}

}
