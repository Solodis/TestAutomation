package com.epam.vyacheslav_utenkov.java.lesson4.task1;

import java.util.Date;

public class Tester {

	public static void main(String[] args) {
		//System.out.println(programm.getEndDate());
		Programm programm = new Programm("!!!");
		programm.setStartDate(new Date());
		System.out.println(programm.getAllProgramTime());
	}
}
