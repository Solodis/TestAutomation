package com.epam.vyacheslav_utenkov.java.lesson4.task1;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class Programm {
	private String programmName;
	private int programmDuration = 0;
	private final int START_WORKING_TIME = 10;
	private final int END_WORKING_TIME = 18;
	private final int WORKING_HOURS = 8;
	private Date startDate;
	private GregorianCalendar calendar;
	private int hoursBeforeTheEnd = 0;
	private int daysBeforeTheEnd = 0;

	private List<Course> courses = new ArrayList<Course>();

	public Programm(String programmName) {
		this.programmName = programmName;
	}

	public String getProgrammName() {
		return programmName;
	}

	public void setProgrammName(String programmName) {
		this.programmName = programmName;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setProgramm(List<Course> courses) {
		this.courses = courses;
	}

	public int getProgrammDuration() {

		for (Course course : courses) {
			programmDuration += course.getCourseDuration();
		}

		return programmDuration;
	}

	public void setStartDate(Date date) {
		this.startDate = date;
	}

	public Date getEndDate() {
		this.calendar = new GregorianCalendar();
		calendar.setTime(startDate);

		Calendar calendar = new GregorianCalendar();
		SimpleDateFormat form = new SimpleDateFormat("HH");
		for (int i = 0; i < getProgrammDuration(); i++) {
			int hour = Integer.parseInt(form.format(calendar.getTime()));
			while (hour >= END_WORKING_TIME) {
				calendar.clear(Calendar.MINUTE);
				calendar.clear(Calendar.SECOND);
				calendar.add(Calendar.HOUR, 1);
				hour = Integer.parseInt(form.format(calendar.getTime()));
			}
			hour = Integer.parseInt(form.format(calendar.getTime()));
			while (hour < START_WORKING_TIME) {
				calendar.add(Calendar.HOUR, 1);
				hour = Integer.parseInt(form.format(calendar.getTime()));
			}

			calendar.add(Calendar.HOUR, 1);

		}

		return calendar.getTime();
	}

	public String getProgramStatus(){
		
		SimpleDateFormat hourFormat = new SimpleDateFormat("HH");
		SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
		int startDay = Integer.parseInt(dayFormat.format(startDate));
		int startHour = Integer.parseInt(hourFormat.format(startDate));
		int endDay = Integer.parseInt(dayFormat.format(getEndDate()));
		int endHour = Integer.parseInt(hourFormat.format(getEndDate()));
		
		daysBeforeTheEnd = endDay - startDay;
		if(daysBeforeTheEnd < 0){
			daysBeforeTheEnd = startDay - endDay;
			
			if(startHour < endHour){
				daysBeforeTheEnd -= 1;
				
				hoursBeforeTheEnd = (startHour + WORKING_HOURS) - endHour;
				
			}else{
				
				hoursBeforeTheEnd = startHour - endHour;
			}
			
			return "was completed. Passed time " + daysBeforeTheEnd + " d " + hoursBeforeTheEnd + " hrs";
		}
		if(startHour > endHour){
			daysBeforeTheEnd -= 1;
			
			hoursBeforeTheEnd = (endHour + WORKING_HOURS) - startHour;
		}else{
			hoursBeforeTheEnd = endHour - startHour;
		}
		
		
		return "not complete. Time for complete - " + daysBeforeTheEnd + " d " + hoursBeforeTheEnd + " hrs";
	}
}
