package com.epam.vyacheslav_utenkov.java.lesson4.task1;

import java.util.ArrayList;
import java.util.List;

public class EducationalCenter {
	List<Student> students = new ArrayList<Student>();
	private final String LIGHT_EDITION = "0";
	private final String FULL_EDITION = "1";
	
	
	public void addStudent(Student stedent){
		students.add(stedent);
	}
	
	public void showStudentData(String edition) throws IllegalAccessException{
		if(edition.equals(LIGHT_EDITION)){
			for(Student student: students){
				student.getLightData();
			}
		} else if(edition.equals(FULL_EDITION)){
			for(Student student: students){
				student.getFullData();
			}
		} else {
			throw new IllegalAccessException();
		}
	}
}
