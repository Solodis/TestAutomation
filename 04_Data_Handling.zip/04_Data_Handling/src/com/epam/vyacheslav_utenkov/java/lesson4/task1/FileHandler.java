package com.epam.vyacheslav_utenkov.java.lesson4.task1;

import java.util.ResourceBundle;

public class FileHandler {
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.epam.vyacheslav_utenkov.java.lesson4.task1.locale");
	
	public String getString(String key){
		
		return resourceBundle.getString(key);
		
	}
}
