package com.epam.vyacheslav_utenkov.java.lesson7.exceptions;

public class UnknowDriverException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8072827637715807618L;

}
