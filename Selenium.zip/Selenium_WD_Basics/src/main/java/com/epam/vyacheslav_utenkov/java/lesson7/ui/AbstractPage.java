package com.epam.vyacheslav_utenkov.java.lesson7.ui;

import org.openqa.selenium.WebDriver;

import com.epam.vyacheslav_utenkov.java.lesson7.driver.Driver;

public class AbstractPage {
	protected WebDriver driver = Driver.getDriver();
}
