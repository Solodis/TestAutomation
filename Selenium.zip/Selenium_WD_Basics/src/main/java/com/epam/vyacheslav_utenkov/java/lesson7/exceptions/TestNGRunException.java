package com.epam.vyacheslav_utenkov.java.lesson7.exceptions;

public class TestNGRunException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5649898792805451564L;
	
	public TestNGRunException(String message) {
		super(message);
	}

}
