package TestAutomation.TestAutomationByWD;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import Drivers.Driver;
import Pages.MainPage;
import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase {
	WebDriver driver = null;
	
	@BeforeTest
	public void startBrowser() {
		driver = Driver.getDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.youtube.com/");

	}
	
	@Test
	public void search() {
		System.out.println(driver);
		MainPage mainPage = new MainPage();
		mainPage.insertRequest("dsgseg");
		mainPage.startSearching();
	}
	
	@Test
	public void smokeTest(){
		MainPage mainPage = new MainPage();
		new Assertion().assertEquals(mainPage.getMoviesButton().isDisplayed(), true);
		new Assertion().assertEquals(mainPage.getMusicButton().isDisplayed(), true);
		new Assertion().assertEquals(mainPage.getShowsButton().isDisplayed(), true);
		new Assertion().assertEquals(mainPage.getSportsButton().isDisplayed(), false);
		new Assertion().assertEquals(mainPage.getSpotlightButton().isDisplayed(), true);
		new Assertion().assertEquals(mainPage.getVideoButton().isDisplayed(), true);
	}
	
	//@AfterTest
	//public void quit(){
	//	driver.quit();
	//}

}
