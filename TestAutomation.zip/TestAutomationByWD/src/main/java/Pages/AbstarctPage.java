package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Drivers.Driver;

public abstract class AbstarctPage {
	
	public WebDriver driver;
	
	@FindBy(xpath = "//*[@role='search']/form")
	protected WebElement searchFieldList;
	
	@FindBy(xpath = "//button[@id='search-icon-legacy']")
	protected WebElement searchButton;
	
	@FindBy(xpath = "//button[@id='guide-button']")
	protected WebElement guideButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'Music')]")
	protected WebElement musicButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'Sports')]")
	protected WebElement sportsButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'Gaming')]")
	protected WebElement gamingButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'Movies')]")
	protected WebElement moviesButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'TV Shows')]")
	protected WebElement showsButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'News')]")
	protected WebElement newsButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'Live')]")
	protected WebElement liveButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), 'Spotlight')]")
	protected WebElement spotlightButton;
	
	@FindBy(xpath = "//a[@id='endpoint']/span[contains(text(), '360° Video')]")
	protected WebElement videoButton;
	
	public AbstarctPage (){
		this.driver = Driver.getDriver();
	}
}
