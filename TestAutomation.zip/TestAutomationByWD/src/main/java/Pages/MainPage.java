package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

public class MainPage extends AbstarctPage{
	
	public MainPage(){
		PageFactory.initElements(this.driver, this);
	}
	
	public MainPage insertRequest(String request){
		new Actions(driver).click(searchFieldList).build().perform();
		new Actions(driver).sendKeys(searchFieldList, "Простые мысли").build().perform();
		return this;
	}
	
	public MainPage startSearching(){
		new Actions(driver).click(searchButton).build().perform();
		return this;
	}
	
	public WebElement getMusicButton(){
		return musicButton;
	}
	
	public WebElement getMoviesButton(){
		return moviesButton;
	}
	
	public WebElement getShowsButton(){
		return showsButton;
	}
	
	public WebElement getSportsButton(){
		return sportsButton;
	}
	
	public WebElement getSpotlightButton(){
		return spotlightButton;
	}
	
	public WebElement getVideoButton(){
		return videoButton;
	}

}
